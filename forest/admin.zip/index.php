
<?php 
include_once("assets/inc/head.php");
?>

        <div class="content">
            <div class="container-fluid">
                <a href="admin.php" class="btn btn-primary">Admin</a>
                <a href="manager.php" class="btn btn-primary">Owner</a>
                <a href="user.php" class="btn btn-primary">User</a>


                
            </div>
        </div>
<?php 
include_once("assets/inc/foot.php");
?>
