<?php
include_once('../dbconnect.php');
loginrequired('manager');
date_default_timezone_set('Asia/Kolkata');
$uid=$_SESSION['uid'];
include_once("assets/inc/head.php");
?>
 <div class="jumbotron">
        <h1>WELCOME</h1>
</div>
    <table class="table">
     <thead>
        <th>Sl No.</th>
        <th>Name</th>
        <th>Details</th>
        <th>Price</th>
        <th>Status</th>
        <th>Option</th>
     </thead>
     <tbody>
        <?php

        $qry="SELECT * FROM `packages` WHERE ManagerId=$uid";
        //echo($qry);
        $res=mysql_query($qry);
        $i=0;
        while($row=mysql_fetch_assoc($res)){
            ?>
        <tr>
        <td><?php echo(++$i); ?></td>
        <td><?php echo($row['PackageName']) ?></td>
        <td><?php echo($row['PackageDetails']) ?></td>
        <td><?php echo($row['Price']) ?></td>
        <td>
            <?php 
                if($row['Active']==1){
                    echo("active");
                } 
                if($row['Active']==-1){
                    echo("pending");
                } 
                if($row['Active']==0){
                    echo("rejected");
                } 
            ?>
        </td>
        <td>
        <button class="btn">delete</button>
        </td>
        </tr>
        <?php
        }
        ?>
     </tbody>
    </table>
    <?php
include_once("assets/inc/foot.php");
?>