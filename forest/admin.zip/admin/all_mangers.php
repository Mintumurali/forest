<?php
include_once("../dbconnect.php");
loginrequired('admin');
include_once("assets/inc/head.php");
?>
<div class="jumbotron">
        <h1>All Manager</h1>
    </div>
 
<table class="table">
     <thead>
        <th>Sl No.</th>
        <th>Name</th>
        <th>Option</th>
     </thead>
     <tbody>
        <?php
                $qry="SELECT * FROM `manager`";
                //echo($qry);
                $res=mysql_query($qry);
                $i=0;
                while($row=mysql_fetch_assoc($res)){
        ?>
        <tr>
            <td><?php echo(++$i); ?></td>
            <td><?php echo($row['Name']) ?></td>
            <td><button class="btn">delete</button></td>
        </tr>
        <?php
                 }
        ?>
     </tbody>
    </table>
    <?php
include_once("assets/inc/foot.php");
?>