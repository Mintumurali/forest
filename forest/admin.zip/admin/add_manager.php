<?php
include_once("../dbconnect.php");
loginrequired('admin');
if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $password=$_POST['password'];
    $qry="INSERT INTO `manager`(`AutoId`, `Name`, `Password`) VALUES ('','$name','$password')";
    if(mysql_query($qry)){
        echo("manager added successfully");
    }
}
?>



<?php
include_once("../dbconnect.php");
loginrequired('admin');
include_once("assets/inc/head.php");
?>
    <div class="jumbotron">
        <h1>Add Manager</h1>
    </div>
    <div class="card col-4">
    <form action="" method="post" class="form">
    <div class="card-body">
        <label for="">Manger Name</label>
        <input  class="form-control" type="text" name="name" id="name" placeholder="name">
        <label for="">Manger Password</label>
        <input type="password"  class="form-control" name="password" id="password" placeholder="password">
    </div>
    <div class="card-footer">
     <button type="submit" class="form-control btn" name="submit">add Manager</button>
     </div>
    </form>
   
    </div>
<?php
include_once("assets/inc/foot.php");
?>



