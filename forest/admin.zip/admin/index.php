<?php
include_once("../dbconnect.php");
loginrequired('admin');
include_once("assets/inc/head.php");
?>

    <div class="jumbotron">
        <h1>WELCOME</h1>
    </div>
<?php
include_once("assets/inc/foot.php");
?>