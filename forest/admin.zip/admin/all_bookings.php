<?php
include_once("../dbconnect.php");
loginrequired('admin');
include_once("assets/inc/head.php");
?>
<div class="jumbotron">
        <h1>All Bookings</h1>
    </div>
<table class="table">
     <thead>
        <th>Sl No.</th>
        <th>Package Name</th>
        <th>Username</th>
        <th>Owner Id</th>
        <th>Option</th>
     </thead>
     <tbody>
        <?php
                $qry="SELECT booking.AutoId bookingId,booking.PackageId pid,booking.UserId uid, user.Name uname,packages.PackageName pname,packages.ManagerId mid FROM `booking` JOIN packages on booking.PackageId=packages.AutoId JOIN user on user.AutoId=booking.UserId";
                //echo($qry);
                $res=mysql_query($qry);
                $i=0;
                while($row=mysql_fetch_assoc($res)){
        ?>
        <tr>
            <td><?php echo(++$i); ?></td>
            <td><?php echo($row['pname']) ?></td>
            <td><?php echo($row['uname']) ?></td>
            <td><?php echo($row['mid']) ?></td>
            <td><button class="btn">delete</button></td>
        </tr>
        <?php
                 }
        ?>
     </tbody>
    </table>
    
<<?php
include_once("assets/inc/foot.php");
?>