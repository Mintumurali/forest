<?php
include_once("../dbconnect.php");
$pid=$_GET['id'];
$uid=$_SESSION['uid'];
$qry="INSERT INTO `booking`
                (`AutoId`, `PackageId`, `UserId`, `Status`) 
            VALUES ('','$pid','$uid','1')";

mysql_query($qry);
header("location:index.php");
?>