<?php
include_once("../dbconnect.php");
loginrequired('user');
$uid=$_SESSION['uid'];
?>

<?php
include_once("assets/inc/head.php");
?>

    <div class="jumbotron">
        <h1>WELCOME</h1>
    </div>

<header> <h3>All Packages</h3></header>
<br>
<table class="table">
     <thead>
        <th>Sl No.</th>
        <th>Name</th>
        <th>Details</th>
        <th>Price</th>
        <!-- <th>Status</th> -->
        <th>Option</th>
     </thead>
     <tbody>
        <?php

        $qry="SELECT * FROM `packages` where Active=1";
        //echo($qry);
        $res=mysql_query($qry);
        $i=0;
        while($row=mysql_fetch_assoc($res)){
            ?>
        <tr>
        <td><?php echo(++$i); ?></td>
        <td><?php echo($row['PackageName']) ?></td>
        <td><?php echo($row['PackageDetails']) ?></td>
        <td><?php echo($row['Price']) ?></td>
        <td>
        <a class="btn" href="purchase.php?id=<?php  echo($row['AutoId']);?>">Purchase</a>
        </td>
        </tr>
        <?php
        }
        ?>
     </tbody>
    </table>
<br>
<br>    

<header><h3>Your Bookings</h3></header>
<br>
<table class="table">
     <thead>
        <th>Sl No.</th>
        <th>Package Name</th>
        <!-- <th>Username</th>
        <th>Owner Id</th>
        <th>Option</th> -->
     </thead>
     <tbody>
        <?php
                $qry="SELECT booking.AutoId bookingId,booking.PackageId pid,booking.UserId uid, user.Name uname,packages.PackageName pname,packages.ManagerId mid FROM `booking` JOIN packages on booking.PackageId=packages.AutoId JOIN user on user.AutoId=booking.UserId where booking.UserId = $uid";
                //echo($qry);
                $res=mysql_query($qry);
                $i=0;
                while($row=mysql_fetch_assoc($res)){
        ?>
        <tr>
            <td><?php echo(++$i); ?></td>
            <td><?php echo($row['pname']) ?></td>
            <!-- <td><?php echo($row['uname']) ?></td>
            <td><?php echo($row['mid']) ?></td>
            <td><button>delete</button></td> -->
        </tr>
        <?php
                 }
        ?>
     </tbody>
    </table>
    





<?php
include_once("assets/inc/foot.php");
?>
